export default class FilaRastrAbertos{
    elementos = [];

    adicionarRastreador(rastreador){
        this.elementos.push(rastreador);
        this.ordenarFila();}
    
    ordenarFila(){
            this.elementos.sort((a,b)=>{
                return a.getCusto() - b.getCusto();
    });}

    pegarPrimeiroFila(){
        return this.elementos.shift();}
    
    buscarRastreador(verticeBuscado){
        let rastreadorEncontrado = null;
        
        this.elementos.forEach(rastreador =>{
            if(rastreador.vertice == verticeBuscado){
                rastreadorEncontrado = rastreador;}})
                return rastreadorEncontrado;}

    substituirRastreador(rastreadorVelho, rastreadorNovo){
        let indexAnterior = this.elementos.indexOf(rastreadorVelho);
        this.elementos[indexAnterior] = rastreadorNovo;
        this.ordenarFila();}
}