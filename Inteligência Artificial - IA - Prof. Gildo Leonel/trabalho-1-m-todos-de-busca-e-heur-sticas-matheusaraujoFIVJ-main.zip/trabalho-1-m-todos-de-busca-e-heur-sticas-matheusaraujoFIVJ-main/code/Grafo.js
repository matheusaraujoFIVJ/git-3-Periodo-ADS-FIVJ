import FilaRastrAbertos from "./FilaRastrAbertos.js";
import Rastreador from "./Rastreador.js";

export default class Grafo {
    inicio = null;
    final = null;

    constructor(inicio, final) {
        this.inicio = inicio;
        this.final = final;}

 
        buscaAEstrela(){
        let rastreadoresAbertos = new FilaRastrAbertos();
        let atual = null;
        let rastreadoresFechados = new Map();

        rastreadoresAbertos.adicionarRastreador(new Rastreador(this.inicio, null, 0));
        atual = rastreadoresAbertos.pegarPrimeiroFila();

        while(atual != null){
            if(atual.vertice == this.final){
                return atual
            }else{
                rastreadoresFechados.set(atual.vertice.ponto, atual);
                atual.vertice.adjacentes.forEach(aresta =>{
                    let v = aresta.destino;

                    if(!rastreadoresFechados.has(v.ponto)){
                        let rastreadorVelho = rastreadoresAbertos.buscarRastreador(v);
                        let rastreadorNovo = new Rastreador(v, atual, v.heuristica);

                        if(!rastreadorVelho){
                            rastreadoresAbertos.adicionarRastreador(rastreadorNovo);
                        }else{
                            if(rastreadorNovo.getCusto() < rastreadorVelho.getCusto()){
                                rastreadoresAbertos.substituirRastreador(rastreadorVelho,rastreadorNovo);}}
                    }
                })
            }
            atual = rastreadoresAbertos.pegarPrimeiroFila();
        }
        return null;
    }
}