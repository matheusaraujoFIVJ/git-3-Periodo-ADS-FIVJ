export default class Aresta{
    origem = null;
    destino = null;
    peso = 0;

    constructor(origem, destino, peso){
        this.origem = origem;
        this.destino = destino;
        this.peso = peso;}
}