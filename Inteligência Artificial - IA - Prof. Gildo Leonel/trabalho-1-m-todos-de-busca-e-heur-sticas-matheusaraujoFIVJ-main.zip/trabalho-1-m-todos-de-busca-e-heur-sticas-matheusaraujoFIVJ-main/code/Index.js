import Grafo from "./Grafo.js";
import Rastreador from "./Rastreador.js";
import Vertice from "./Vertice.js";

let a = new Vertice ("a", null);
let b = new Vertice ("b", 32);
let c = new Vertice ("c", 11);
let d = new Vertice ("d", 6);
let e = new Vertice ("e", 7);
let f = new Vertice ("f", 3);
let g = new Vertice ("g", 6);
let h = new Vertice ("h", 1);
let i = new Vertice ("i", 2);
let j = new Vertice ("j", null);



let grafo = new Grafo(a, j);

a.adicionarAresta(b,10);
b.adicionarAresta(c,27);
c.adicionarAresta(d,9);
c.adicionarAresta(g,36);
d.adicionarAresta(e,10);
d.adicionarAresta(f,8);
e.adicionarAresta(j,29);
f.adicionarAresta(i,4);
f.adicionarAresta(h,7);
g.adicionarAresta(j,20);
h.adicionarAresta(j,11);
i.adicionarAresta(j,12);


let caminho = grafo.buscaAEstrela();


console.log("O melhor caminho encontrado pela busca A* é: ");
caminho.imprimirCaminho();
console.log( "O tempo aproximado para este caminho é de " + caminho.getCusto() + " minutos");