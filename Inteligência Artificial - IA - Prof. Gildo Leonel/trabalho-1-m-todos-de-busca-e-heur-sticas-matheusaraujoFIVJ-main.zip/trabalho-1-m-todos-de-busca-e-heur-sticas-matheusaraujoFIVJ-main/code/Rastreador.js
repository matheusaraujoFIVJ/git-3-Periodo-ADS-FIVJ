export default class Rastreador{
    custo = 0;
    heuristica = null;
    rastreadorVelho= null;
    vertice = null;

    constructor(vertice, rastreadorVelho, heuristica){
        this.vertice = vertice;
        this.rastreadorVelho= rastreadorVelho;
        this.heuristica = heuristica;

        if(rastreadorVelho != null){
            this.custo = this.rastreadorVelho.custo + this.rastreadorVelho.vertice.buscarAresta(this.vertice).peso;}}

    imprimirCaminho(){
        let caminho = this.ordenarCaminho();
        let saida = "";
        
        caminho.forEach(rastreador => {
            if(caminho.indexOf(rastreador) == 0 ){
                saida += rastreador.vertice.ponto;
            }else{
                saida += " ----> " + rastreador.vertice.ponto;}});
        console.log(saida + "\n");}
       
    ordenarCaminho(){
        let arrayRastreador = [];
        let atual = this;
        
        arrayRastreador.push(atual);

        while(atual.rastreadorVelho != null){
            atual = atual.rastreadorVelho;
            arrayRastreador.push(atual);}

        return arrayRastreador.reverse();}

    getCusto(){
        return this.custo + this.heuristica;}
}