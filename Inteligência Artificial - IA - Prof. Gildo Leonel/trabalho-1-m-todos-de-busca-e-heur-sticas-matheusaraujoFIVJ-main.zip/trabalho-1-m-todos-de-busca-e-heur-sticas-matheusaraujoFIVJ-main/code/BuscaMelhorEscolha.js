/*

import Grafo from "./Grafo.js";
import Index from "./Index.js";

function buscaMelhorEscolha(grafo, origem, destino) {
    let visitados = new Set();
    let caminho = [];
    let custoTotal = 0;

    let atual = origem;
    while (atual !== destino) {
        visitados.add(atual);
        caminho.push(atual);

        let adjacencias = grafo.vertices[atual];
        let melhorAdjacente;
        let menorCusto = Infinity;

        for (let adjacente in adjacencias) {
            if (!visitados.has(adjacente) && adjacencias[adjacente] < menorCusto) {
                melhorAdjacente = adjacente;
                menorCusto = adjacencias[adjacente];
            }
        }

        if (!melhorAdjacente) {
            console.log("Não foi possível encontrar um caminho até o destino.");
            return;
        }

        custoTotal += menorCusto;
        atual = melhorAdjacente;
    }

    caminho.push(destino);
    return { caminho, custoTotal };
}

function imprimeCaminho(caminho, custoTotal) {
    console.log(caminho.join(' --> '));
    console.log("Custo total:", custoTotal);
}

export default { buscaMelhorEscolha, imprimeCaminho };
*/